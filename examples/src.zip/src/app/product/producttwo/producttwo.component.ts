import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-producttwo',
  templateUrl: './producttwo.component.html',
  styleUrls: ['./producttwo.component.css']
})
export class ProducttwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
