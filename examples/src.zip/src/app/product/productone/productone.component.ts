import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-productone',
  templateUrl: './productone.component.html',
  styleUrls: ['./productone.component.css']
})
export class ProductoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
